public enum ClassType {
    LEC, TUT, LAB
}
