/**
 * this room class represents a room which is associated with a scheduled timetable slot.
 * a classroom is used for a lecture and tutorial while labs are scheduled in lab rooms.
 * a room has attributes id, type, capacity and availability.
 */
//
public class Rooms {
    private String roomID; //csg001
    private int roomCapacity; //300
    private String roomType;//lecture hall
    private boolean isAvailable;
    private static final String[] roomTypes = {"teaching", "CSlab"};

    /**
     *
     * @param roomId the unique identifier for the room(must be null)
     * @param roomType the type of room being used.
     * @param roomCapacity The max number of people inside the room
     *
     * @throws IllegalArgumentException If the argument is invalid or the room type is not recognizable
     */
    public Rooms(String roomId, String roomType, int roomCapacity) {
        if (roomId == null || roomCapacity < 0 || roomType == null) {
            throw new IllegalArgumentException("Invalid arguments");
        }
        if (!validRoomType(roomType)) {
            throw new IllegalArgumentException("Invalid Room type " + roomType);
        }
        this.roomID = roomId;
        this.roomCapacity = roomCapacity;
        this.roomType = roomType;
        this.isAvailable = isAvailable;
    }

    /**
     * @return the rooms id
     */
    public final String getRoomId() {
        return roomID;}
    /**
     *
     * @return the rooms capacity
     */
    public final int getRoomCapacity() {
        return roomCapacity;}

    /**
     * @return the rooms type
     */
    public final String getType() {
        return roomType;}

    /**
     * @return the availability
     */
    public final boolean isAvailable() {
        return isAvailable;
    }

    /**
     *
     * @param roomType The room type to validate
     * @return true if the type exists
     */
    public Boolean validRoomType(String roomType) {
        for (int i = 0; i < roomTypes.length; i++) {
            if (roomTypes[i].equalsIgnoreCase(roomType)) {
                return true;
            }
        }
        return false;
    }
}
