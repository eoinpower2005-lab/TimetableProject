public enum ClassType {
    LECTURE, TUT, LAB
}
